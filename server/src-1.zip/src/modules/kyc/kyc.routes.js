const router = require("express").Router();
const { authJwt } = require("../../middlewares/authJwt");
const controller = require("./kyc.controller");

router.post("/submit", authJwt, controller.submit);
router.get("/status", authJwt, controller.status);

// ✅ Admin UI: list applications
router.get("/admin/applications", authJwt, controller.listApplications);

// ✅ Admin: approve/reject
router.post("/admin/review", authJwt, controller.review);

module.exports = router;
