const { submitKycSchema, reviewKycSchema } = require("./kyc.validators");
const service = require("./kyc.service");
const { z } = require("zod");

const listQuerySchema = z.object({
  status: z.enum(["NOT_SUBMITTED", "PENDING", "APPROVED", "REJECTED"]).optional(),
  limit: z.coerce.number().finite().optional(),
  offset: z.coerce.number().finite().optional(),
});

function getCtx(req) {
  const raw = req.headers["x-device-id"];
  const deviceId = typeof raw === "string" && raw.trim() ? raw.trim().slice(0, 128) : null;

  return {
    ip: req.headers["x-forwarded-for"]?.toString().split(",")[0]?.trim() || req.ip,
    ua: req.headers["user-agent"] || null,
    deviceId,
  };
}

async function submit(req, res, next) {
  try {
    const input = submitKycSchema.parse(req.body);
    const out = await service.submitKyc(req.auth.userId, input, getCtx(req));
    res.json({ ok: true, ...out });
  } catch (e) {
    next(e);
  }
}

async function status(req, res, next) {
  try {
    const out = await service.getKycStatus(req.auth.userId);
    res.json({ ok: true, kyc: out });
  } catch (e) {
    next(e);
  }
}

// ✅ Admin UI list
async function listApplications(req, res, next) {
  try {
    if (req.auth.role !== "admin") {
      return res.status(403).json({ ok: false, error: "Forbidden" });
    }

    const q = listQuerySchema.parse(req.query);
    const out = await service.listApplications({
      status: q.status,
      limit: q.limit ?? 50,
      offset: q.offset ?? 0,
    });

    return res.json({ ok: true, ...out });
  } catch (e) {
    next(e);
  }
}

// ✅ Admin approve/reject
async function review(req, res, next) {
  try {
    if (req.auth.role !== "admin") {
      throw Object.assign(new Error("Forbidden"), { status: 403 });
    }

    const input = reviewKycSchema.parse(req.body);

    const out = await service.reviewKyc(
      {
        adminUserId: req.auth.userId,
        userId: input.userId,
        decision: input.decision,
        notes: input.notes ?? null,
      },
      getCtx(req)
    );

    res.json({ ok: true, ...out });
  } catch (e) {
    next(e);
  }
}

module.exports = { submit, status, listApplications, review };
