const { z } = require("zod");

const adminAdjustSchema = z
  .object({
    userId: z.string().uuid(),
    type: z.enum(["DEPOSIT", "WITHDRAW", "ADJUST"]),
    // Accepts "100" or 100, rejects NaN and +/-Infinity
    amount: z.coerce.number().finite(),
    description: z.string().trim().min(1).max(255),
    referenceId: z.string().uuid(),
  })
  .superRefine((data, ctx) => {
    // Strict rules:
    // - DEPOSIT/WITHDRAW must be > 0
    // - ADJUST can be +/- but must not be 0
    if (data.type === "ADJUST") {
      if (data.amount === 0) {
        ctx.addIssue({
          code: z.ZodIssueCode.custom,
          path: ["amount"],
          message: "ADJUST amount must be non-zero",
        });
      }
      return;
    }

    if (data.amount <= 0) {
      ctx.addIssue({
        code: z.ZodIssueCode.custom,
        path: ["amount"],
        message: `${data.type} amount must be > 0`,
      });
    }
  });

const listTxQuerySchema = z.object({
  limit: z.coerce.number().int().min(1).max(200).optional(),
  offset: z.coerce.number().int().min(0).optional(),
});

module.exports = { adminAdjustSchema, listTxQuerySchema };
