const router = require("express").Router();
const { authJwt } = require("../../middlewares/authJwt");
const controller = require("./wallet.controller");

router.get("/me", authJwt, controller.me);
router.get("/transactions", authJwt, controller.myTransactions);
router.post("/admin/adjust", authJwt, controller.adminAdjust);

module.exports = router;
