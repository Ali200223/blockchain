// server/src/modules/trade/tradeReversal.controller.js
const { z } = require("zod");
const { reverseTradeFill } = require("./tradeReversal.service");

const bodySchema = z.object({
  referenceId: z.string().trim().min(8).max(64), // idempotency key
  reason: z.string().trim().min(1).max(255).optional(),
});

async function reverseTradeFillController(req, res, next) {
  try {
    const tradeFillId = Number(req.params.id);
    if (!Number.isFinite(tradeFillId) || tradeFillId <= 0) {
      return res.status(400).json({ ok: false, error: "Invalid fill id" });
    }

    const body = bodySchema.parse(req.body || {});

    const result = await reverseTradeFill({
      tradeFillId,
      referenceId: body.referenceId,
      reason: body.reason || "trade_reversal",
      actor: req.auth, // { userId, role, ... }
      requestId: req.ctx?.requestId || null,
    });

    return res.json({ ok: true, ...result });
  } catch (err) {
    next(err);
  }
}

module.exports = { reverseTradeFillController };
