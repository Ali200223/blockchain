const { pool } = require("../../config/mysql");

function toFiniteNumber(v) {
  const n = Number(v);
  if (!Number.isFinite(n)) {
    throw Object.assign(new Error("Invalid amount"), { status: 400 });
  }
  return n;
}

// Keep 2dp to match DECIMAL(18,2) semantics
function round2(n) {
  return Math.round((n + Number.EPSILON) * 100) / 100;
}

function computeDelta(type, amountRaw) {
  const typeNorm = String(type || "").toUpperCase();
  const a0 = toFiniteNumber(amountRaw);
  const a = round2(a0);

  if (!Number.isFinite(a)) {
    throw Object.assign(new Error("Invalid amount"), { status: 400 });
  }

  if (typeNorm === "DEPOSIT") {
    if (a <= 0) throw Object.assign(new Error("Invalid amount"), { status: 400 });
    return +a;
  }

  if (typeNorm === "WITHDRAW") {
    if (a <= 0) throw Object.assign(new Error("Invalid amount"), { status: 400 });
    return -a;
  }

  if (typeNorm === "ADJUST") {
    if (a === 0) throw Object.assign(new Error("Invalid amount"), { status: 400 });
    // ADJUST is a signed delta (can be + or -)
    return a;
  }

  throw Object.assign(new Error("Invalid type"), { status: 400 });
}

async function getWallet(userId) {
  const [rows] = await pool.execute(
    `SELECT user_id, balance, currency, status, updated_at
     FROM wallets
     WHERE user_id = :userId
     LIMIT 1`,
    { userId }
  );

  if (!rows.length) return null;
  return rows[0];
}

async function listMyTransactions(userId, limit = 50) {
  const lim = Math.max(1, Math.min(200, Number(limit) || 50));
  const [rows] = await pool.execute(
    `
    SELECT type, amount, balance_after, description, reference_id, created_at
    FROM v_user_wallet_transactions
    WHERE user_id = :userId
    ORDER BY created_at DESC
    LIMIT ${lim}
    `,
    { userId }
  );
  return { limit: lim, items: rows };
}

async function applyWalletTx(conn, { userId, type, amount, description, referenceId = null }) {
  // Normalize inputs defensively
  const typeNorm = String(type || "").toUpperCase();
  const descNorm = String(description || "").trim();
  const refNorm =
    referenceId == null ? null : String(referenceId).trim() === "" ? null : String(referenceId).trim();

  // lock wallet row
  const [wRows] = await conn.execute(
    `SELECT balance, status
     FROM wallets
     WHERE user_id = :userId
     FOR UPDATE`,
    { userId }
  );

  if (!wRows.length) throw Object.assign(new Error("Wallet not found"), { status: 404 });

  if (wRows[0].status !== "ACTIVE") {
    throw Object.assign(new Error("Wallet locked (KYC not approved)"), { status: 403 });
  }

  const oldBal = round2(toFiniteNumber(wRows[0].balance));
  const delta = computeDelta(typeNorm, amount);
  const newBal = round2(oldBal + delta);

  // STRICTEST RULE: never allow balance to go below 0 for any type
  if (newBal < 0) {
    throw Object.assign(new Error("Insufficient funds"), { status: 409 });
  }

  await conn.execute(
    `UPDATE wallets
     SET balance = :newBal
     WHERE user_id = :userId`,
    { userId, newBal }
  );

  // amount stored as signed delta (WITHDRAW negative, ADJUST may be negative)
  await conn.execute(
    `INSERT INTO wallet_transactions
      (user_id, type, amount, balance_after, description, reference_id, status)
     VALUES
      (:userId, :type, :amount, :balanceAfter, :desc, :refId, 'CONFIRMED')`,
    {
      userId,
      type: typeNorm,
      amount: delta,
      balanceAfter: newBal,
      desc: descNorm,
      refId: refNorm,
    }
  );

  return { balance: newBal };
}

async function adjustWalletAtomic({ userId, type, amount, description, referenceId = null }) {
  const conn = await pool.getConnection();
  try {
    await conn.beginTransaction();

    const out = await applyWalletTx(conn, {
      userId,
      type,
      amount,
      description,
      referenceId,
    });

    await conn.commit();
    return out;
  } catch (e) {
    await conn.rollback();
    throw e;
  } finally {
    conn.release();
  }
}

module.exports = { getWallet, listMyTransactions, applyWalletTx, adjustWalletAtomic };
