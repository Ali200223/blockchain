const express = require("express");
const router = express.Router();

const { authJwt } = require("../../middlewares/authJwt");
const controller = require("./kyc.controller");
const { env } = require("../../config/env"); // if you already use env elsewhere

// All KYC routes require auth
router.use(authJwt);

// ---------- User routes ----------
router.post("/submit", controller.submit);
router.get("/status", controller.status);

// Keep ONLY ONE documents route (pick the correct controller function)
router.post("/documents", controller.uploadKycDocument); // or controller.uploadDocument

// ---------- Admin gate ----------
function requireAdmin(req, res, next) {
  const a = req.auth || {};
  const role = typeof a.role === "string" ? a.role.toLowerCase() : null;
  const roles = Array.isArray(a.roles) ? a.roles.map((r) => String(r).toLowerCase()) : [];
  const adminIds = String(env.ADMIN_USER_IDS || "")
    .split(",")
    .map((s) => s.trim())
    .filter(Boolean);

  const isAdmin =
    a.isAdmin === true ||
    role === "admin" ||
    roles.includes("admin") ||
    (a.userId != null && adminIds.includes(String(a.userId)));

  if (!isAdmin) return res.status(403).json({ ok: false, error: "Admin only" });
  return next();
}

// ---------- Admin routes ----------
const admin = express.Router();
admin.use(requireAdmin);

admin.get("/applications", controller.listApplications);
admin.post("/review", controller.review);
admin.post("/reveal-doc-number", controller.revealDocNumber);

router.use("/admin", admin);

module.exports = router;
